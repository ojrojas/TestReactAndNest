export interface IBook {
  id: string;
  title: string;
  chapters: number;
  pages: number;
}
