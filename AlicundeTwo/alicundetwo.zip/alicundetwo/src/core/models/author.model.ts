export interface IAuthor {
  id: string;
  name: string;
}
