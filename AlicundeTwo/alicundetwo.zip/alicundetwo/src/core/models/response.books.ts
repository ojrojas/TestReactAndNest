export interface ResponseBook {
  id: string;
  promedio: string;
}
