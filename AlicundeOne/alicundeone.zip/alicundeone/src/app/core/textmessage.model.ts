export interface ITextMessage{ 
    id:string;
    text:string;
}