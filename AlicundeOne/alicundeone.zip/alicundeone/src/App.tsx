import React from 'react';
import './App.css';
import TextMessageComponent from './features/textmessage/textmessage';

const App :React.FC = () =>  {
  return (
   <TextMessageComponent />
  );
}

export default App;
